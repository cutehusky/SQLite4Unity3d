﻿using SQLite4Unity3d;
using SQLite4Unity3d.Example;
using UnityEngine;

namespace SQLite4Unity3d
{
	public class DatabaseManager : SingletonMono<DatabaseManager>
	{
		private SQLiteConnection _connection;
		[SerializeField] protected string databaseName;

		private void Awake()
		{
			Connect();
			// Do somethings
			_connection.Close();
		}

		private void Connect()
		{
#if UNITY_EDITOR
			var dbPath = $@"Assets/StreamingAssets/Database/{databaseName}";
#else
	        // check if file exists in Application.persistentDataPath
	        var filepath = $"{Application.persistentDataPath}/Database/{databaseName}";
	        if (!File.Exists(filepath))
	        {
	            Debug.Log("Database not in Persistent path");
				var dirpath = System.IO.Path.GetDirectoryName(filepath);
				if (!Directory.Exists(dirpath)) 
					Directory.CreateDirectory(dirpath);
	            // if it doesn't ->
	            // open StreamingAssets directory and load the db ->
#if UNITY_ANDROID 
	           var loadDb =
 new WWW("jar:file://" + Application.dataPath + "!/assets/Database/" + databaseName);  // this is the path to your StreamingAssets in android
	           while (!loadDb.isDone) { }  // CAREFUL here, for safety reasons you shouldn't let this while loop unattended, place a timer and error check
	            // then save to Application.persistentDataPath
				File.WriteAllBytes(filepath, loadDb.bytes);
#elif UNITY_IOS
				var loadDb =
 Application.dataPath + "/Raw/Database/" + databaseName;  // this is the path to your StreamingAssets in iOS
	                                                          // then save to Application.persistentDataPath
				File.Copy(loadDb, filepath);
#elif UNITY_WP8
				var loadDb =
 Application.dataPath + "/StreamingAssets/Database/" + databaseName;  // this is the path to your StreamingAssets in iOS
				// then save to Application.persistentDataPath
				File.Copy(loadDb, filepath);
#elif UNITY_WINRT
				var loadDb =
 Application.dataPath + "/StreamingAssets/Database/" + databaseName;  // this is the path to your StreamingAssets in iOS
				// then save to Application.persistentDataPath
				File.Copy(loadDb, filepath);
#elif UNITY_STANDALONE_OSX
				var loadDb =
 Application.dataPath + "/Resources/Data/StreamingAssets/Database/" + databaseName;  // this is the path to your StreamingAssets in iOS
				// then save to Application.persistentDataPath
				File.Copy(loadDb, filepath);
#else
				var loadDb =
 Application.dataPath + "/StreamingAssets/Database/" + databaseName;  // this is the path to your StreamingAssets in iOS
				// then save to Application.persistentDataPath
				File.Copy(loadDb, filepath);
#endif
	            Debug.Log("Database written");
	        }
	        var dbPath = filepath;
#endif
			_connection = new SQLiteConnection(dbPath, SQLiteOpenFlags.ReadWrite
			                                           | SQLiteOpenFlags.Create);
			Debug.Log("Final PATH: " + dbPath);
		}
	}
}